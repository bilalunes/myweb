export const STORAGE_KEYS = {
  USERS: 'chat_users',
  CHAT_HISTORY: 'chat_history',
  ADMIN: 'admin_credentials'
} as const;