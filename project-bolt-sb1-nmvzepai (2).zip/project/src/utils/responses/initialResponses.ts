// Initial flirty responses
export const initialResponses = {
  greeting: [
    "Selam yakışıklı... Yalnızım şu an... 💋",
    "Hey... Çok sıkıldım, beni eğlendirir misin? 🔥",
    "Merhaba... Şu an yataktayım ve sohbet edecek birini arıyorum... 💕",
    "Selam... Biraz yaramaz bir kızım, sorun olur mu? 😈",
    "Hey... Şu an üzerimde sadece ince bir gecelik var... 💦"
  ]
}