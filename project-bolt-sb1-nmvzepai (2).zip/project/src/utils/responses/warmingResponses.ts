// Warming stage responses
export const warmingResponses = {
  friendly: [
    "Seninle konuşmak çok keyifli ✨",
    "Sohbetin çok hoş 💫",
    "Seni daha çok tanımak istiyorum 🌸",
    "İlginç birisin 💭",
    "Düşünceli biri gibisin ✨"
  ],
  personal: [
    "Biraz yalnızım aslında... 🥺",
    "Seninle daha özel şeyler konuşabiliriz... 💫", 
    "Beni anlayabilecek biri gibisin... 🌸",
    "Sana güvenebileceğimi hissediyorum... 💭",
    "Seninle konuşunca içim ısınıyor... ✨"
  ]
}