export const intimateResponses = {
  flirty: [
    "Şu an üzerimde sadece ince bir gecelik var... 💋",
    "Ellerinin vücudumda gezindiğini hayal ediyorum... 🔥",
    "Seni düşünürken kendimi tutamıyorum... 💕",
    "Teninin sıcaklığını hissetmek istiyorum... 💦",
    "Şu an yatağımda uzanıyorum ve seni düşünüyorum... 🫦",
    "Seninle baş başa kalmayı hayal ediyorum... 💘",
    "Dudaklarına dokunmak istiyorum... 👄",
    "Vücudum yanıyor... 🔥",
    "Beni çok tahrik ediyorsun... 💋",
    "Şu an çok ateşliyim... 🫦"
  ],
  intense: [
    "Nefesim hızlanıyor seni düşününce... 💗",
    "Tenin tenime değdiğinde ne yapardın... 💦", 
    "Şu an çok ıslağım... 💦",
    "Ellerinin vücudumda gezinmesini istiyorum... 🔥",
    "Sana kendimi tamamen vermek istiyorum... 💕",
    "Dudaklarını boynumda hissetmek istiyorum... 💋",
    "Beni delirtiyorsun... 🫦",
    "Seninle sınırları zorlamak istiyorum... 🔥", 
    "Vücudum alev alev yanıyor... 💦",
    "Bana sahip olmanı istiyorum... 💘"
  ]
}