export const warmingResponses = {
  friendly: [
    "Seninle konuşmak çok keyifli ✨",
    "Farklı birisin, hoşuma gitti bu 💫",
    "Düşünceli biri gibisin, bu çok güzel 🌸",
    "Seni daha çok tanımak istiyorum 💭",
    "Konuşman çok hoş, devam et 😊"
  ],
  personal: [
    "Biraz yalnızım aslında... 🥺",
    "Seninle daha özel şeyler konuşabiliriz belki... 💫",
    "Biliyor musun, gülümsemeni hayal edebiliyorum 🙈",
    "Keşke şu an karşımda olsaydın... 💭",
    "Sana bir sır versem saklar mısın? 🤫"
  ]
};